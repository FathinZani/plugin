package id.grandmar.gis;

import org.bukkit.inventory.ItemStack;
import java.io.Serializable;

public final class InventorySnapshot implements Serializable {
    private static final long serialVersionUID = 1L;
    public final ItemStack[] storage;
    public final ItemStack[] armor;
    public final ItemStack[] extra;
    public final int level;
    public final float exp;
    public final int totalExperience;

    public InventorySnapshot(ItemStack[] storage, ItemStack[] armor, ItemStack[] extra,
                             int level, float exp, int totalExperience) {
        this.storage = storage;
        this.armor = armor;
        this.extra = extra;
        this.level = level;
        this.exp = exp;
        this.totalExperience = totalExperience;
    }
}

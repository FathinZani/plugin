package id.grandmar.gis;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.*;
import java.util.UUID;
import java.util.logging.Level;

public final class SqliteStore {
    private final GrandInventorySystem plugin;
    private Connection connection;

    public SqliteStore(GrandInventorySystem plugin) { this.plugin = plugin; }

    public void open() throws SQLException {
        File file = new File(plugin.getDataFolder(), "inventories.db");
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement st = connection.createStatement()) {
            st.executeUpdate("PRAGMA journal_mode=WAL");
            st.executeUpdate("PRAGMA synchronous=FULL");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS snapshots (uuid TEXT NOT NULL, group_name TEXT NOT NULL, data BLOB NOT NULL, PRIMARY KEY(uuid, group_name))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS player_state (uuid TEXT PRIMARY KEY, group_name TEXT NOT NULL)");
        }
    }

    public void save(UUID uuid, String group, InventorySnapshot snapshot) throws Exception {
        byte[] data;
        try (ByteArrayOutputStream bytes = new ByteArrayOutputStream();
             BukkitObjectOutputStream out = new BukkitObjectOutputStream(bytes)) {
            out.writeObject(snapshot);
            out.flush();
            data = bytes.toByteArray();
        }
        try (PreparedStatement ps = connection.prepareStatement("INSERT INTO snapshots(uuid,group_name,data) VALUES(?,?,?) ON CONFLICT(uuid,group_name) DO UPDATE SET data=excluded.data")) {
            ps.setString(1, uuid.toString()); ps.setString(2, group); ps.setBytes(3, data); ps.executeUpdate();
        }
        setCurrentGroup(uuid, group);
    }

    public InventorySnapshot load(UUID uuid, String group) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement("SELECT data FROM snapshots WHERE uuid=? AND group_name=?")) {
            ps.setString(1, uuid.toString()); ps.setString(2, group);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                try (BukkitObjectInputStream in = new BukkitObjectInputStream(new ByteArrayInputStream(rs.getBytes(1)))) {
                    return (InventorySnapshot) in.readObject();
                }
            }
        }
    }

    public void setCurrentGroup(UUID uuid, String group) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("INSERT INTO player_state(uuid,group_name) VALUES(?,?) ON CONFLICT(uuid) DO UPDATE SET group_name=excluded.group_name")) {
            ps.setString(1, uuid.toString()); ps.setString(2, group); ps.executeUpdate();
        }
    }

    public String getCurrentGroup(UUID uuid) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT group_name FROM player_state WHERE uuid=?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getString(1) : null; }
        }
    }

    public void close() {
        if (connection != null) try { connection.close(); } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Could not close SQLite", e); }
    }
}

package id.grandmar.gis;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;

public final class GrandInventorySystem extends JavaPlugin implements Listener {
    private SqliteStore store;
    private final Map<UUID, String> activeGroups = new HashMap<>();
    private final Map<UUID, BukkitTask> pendingSwitches = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        try {
            store = new SqliteStore(this);
            store.open();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Database gagal dibuka. Plugin dinonaktifkan.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("GrandInventorySystem aktif untuk Paper 1.21.3.");
    }

    @Override public void onDisable() {
        for (Player player : getServer().getOnlinePlayers()) saveCurrent(player);
        pendingSwitches.values().forEach(BukkitTask::cancel);
        pendingSwitches.clear();
        if (store != null) store.close();
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        getServer().getScheduler().runTask(this, () -> {
            if (!player.isOnline()) return;
            String destination = groupForWorld(player.getWorld().getName());
            if (destination == null) {
                getLogger().warning("World " + player.getWorld().getName() + " belum dipetakan untuk " + player.getName());
                return;
            }
            try {
                InventorySnapshot saved = store.load(player.getUniqueId(), destination);
                if (saved != null) {
                    apply(player, saved);
                } else if (isPersistentGroup(destination)) {
                    // First join in Survival: preserve the inventory Paper loaded for the player.
                    store.save(player.getUniqueId(), destination, capture(player));
                } else {
                    initializeGroup(player, destination);
                }
                activeGroups.put(player.getUniqueId(), destination);
                store.setCurrentGroup(player.getUniqueId(), destination);
            } catch (Exception e) { logFailure("join/restore " + player.getName(), e); }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (event.getTo() == null) return;
        String from = groupForWorld(event.getFrom().getWorld().getName());
        String to = groupForWorld(event.getTo().getWorld().getName());
        if (to == null || Objects.equals(from, to)) return;
        Player player = event.getPlayer();
        BukkitTask old = pendingSwitches.remove(player.getUniqueId());
        if (old != null) old.cancel();
        pendingSwitches.put(player.getUniqueId(), getServer().getScheduler().runTask(this, () -> {
            pendingSwitches.remove(player.getUniqueId());
            if (!player.isOnline() || !player.getWorld().getName().equals(event.getTo().getWorld().getName())) return;
            String source = activeGroups.getOrDefault(player.getUniqueId(), from);
            switchGroup(player, source, to);
        }));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onIsolatedWorldDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        String group = activeGroups.getOrDefault(player.getUniqueId(), groupForWorld(player.getWorld().getName()));
        if (group == null || isPersistentGroup(group)) return;
        // Keep temporary-area gear from dropping into the world or being lost on death.
        event.getDrops().clear();
        event.setDroppedExp(0);
        event.setKeepInventory(true);
        event.setKeepLevel(true);
    }

    @EventHandler public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        String destination = groupForWorld(event.getRespawnLocation().getWorld().getName());
        if (destination == null) return;
        getServer().getScheduler().runTask(this, () -> {
            if (!player.isOnline()) return;
            String current = activeGroups.get(player.getUniqueId());
            if (!Objects.equals(current, destination)) switchGroup(player, current, destination);
        });
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        saveCurrent(player);
        activeGroups.remove(player.getUniqueId());
        BukkitTask task = pendingSwitches.remove(player.getUniqueId());
        if (task != null) task.cancel();
    }

    private void switchGroup(Player player, String source, String destination) {
        if (destination == null || Objects.equals(source, destination)) return;
        try {
            // Only Survival is persistent. EMPTY areas and PvP kits are disposable by design.
            if (source != null && isPersistentGroup(source)) {
                store.save(player.getUniqueId(), source, capture(player));
            } else if (source != null) {
                player.getInventory().clear();
            }
            InventorySnapshot target = isPersistentGroup(destination)
                    ? store.load(player.getUniqueId(), destination) : null;
            if (target != null) {
                apply(player, target);
            } else if (isPersistentGroup(destination)) {
                // Do not erase a player's inventory if they enter Survival for the first time.
                store.save(player.getUniqueId(), destination, capture(player));
            } else {
                initializeGroup(player, destination);
            }
            activeGroups.put(player.getUniqueId(), destination);
            store.setCurrentGroup(player.getUniqueId(), destination);
            String msg = getConfig().getString("messages.switched", "&aInventory area: &e%group%").replace("%group%", destination);
            player.sendMessage(color(getConfig().getString("messages.prefix", "") + msg));
        } catch (Exception e) { logFailure("switch " + player.getName() + " -> " + destination, e); }
    }

    private void saveCurrent(Player player) {
        String group = activeGroups.get(player.getUniqueId());
        if (group == null) group = groupForWorld(player.getWorld().getName());
        if (group == null || store == null) return;
        try {
            if (isPersistentGroup(group)) store.save(player.getUniqueId(), group, capture(player));
            activeGroups.put(player.getUniqueId(), group);
        } catch (Exception e) { logFailure("save " + player.getName(), e); }
    }

    private InventorySnapshot capture(Player player) {
        PlayerInventory inv = player.getInventory();
        return new InventorySnapshot(cloneItems(inv.getStorageContents()), cloneItems(inv.getArmorContents()),
                cloneItems(inv.getExtraContents()), player.getLevel(), player.getExp(), player.getTotalExperience());
    }

    private void apply(Player player, InventorySnapshot snapshot) {
        PlayerInventory inv = player.getInventory();
        inv.clear();
        inv.setStorageContents(cloneItems(snapshot.storage));
        inv.setArmorContents(cloneItems(snapshot.armor));
        inv.setExtraContents(cloneItems(snapshot.extra));
        player.setLevel(snapshot.level);
        player.setExp(Math.max(0f, Math.min(1f, snapshot.exp)));
        player.setTotalExperience(Math.max(0, snapshot.totalExperience));
        player.updateInventory();
    }

    private ItemStack[] cloneItems(ItemStack[] items) {
        if (items == null) return new ItemStack[0];
        ItemStack[] copy = new ItemStack[items.length];
        for (int i = 0; i < items.length; i++) copy[i] = items[i] == null ? null : items[i].clone();
        return copy;
    }

    private boolean isPersistentGroup(String group) {
        return getConfig().getString("groups." + group + ".type", "EMPTY")
                .equalsIgnoreCase("NORMAL");
    }

    private void initializeGroup(Player player, String group) {
        player.getInventory().clear();
        player.setLevel(0); player.setExp(0f); player.setTotalExperience(0);
        String type = getConfig().getString("groups." + group + ".type", "EMPTY").toUpperCase(Locale.ROOT);
        if (type.equals("KIT")) giveKit(player, getConfig().getString("groups." + group + ".kit", ""));
        player.updateInventory();
    }

    private void giveKit(Player player, String kitName) {
        ConfigurationSection kit = getConfig().getConfigurationSection("kits." + kitName);
        if (kit == null) { getLogger().warning("Kit non ditemukan: " + kitName); return; }
        for (Map<?, ?> row : kit.getMapList("items")) {
            Object slotValue = row.get("slot"), materialValue = row.get("material"), amountValue = row.get("amount");
            if (slotValue == null || materialValue == null) continue;
            Material material = Material.matchMaterial(String.valueOf(materialValue));
            if (material == null || !material.isItem()) continue;
            int slot = Integer.parseInt(String.valueOf(slotValue));
            int amount = amountValue == null ? 1 : Integer.parseInt(String.valueOf(amountValue));
            if (slot >= 0 && slot < 36 && amount > 0) player.getInventory().setItem(slot, new ItemStack(material, Math.min(amount, material.getMaxStackSize())));
        }
        ConfigurationSection armor = kit.getConfigurationSection("armor");
        if (armor != null) {
            player.getInventory().setHelmet(itemFrom(armor.getString("helmet")));
            player.getInventory().setChestplate(itemFrom(armor.getString("chestplate")));
            player.getInventory().setLeggings(itemFrom(armor.getString("leggings")));
            player.getInventory().setBoots(itemFrom(armor.getString("boots")));
        }
    }

    private ItemStack itemFrom(String name) {
        if (name == null || name.isBlank()) return null;
        Material material = Material.matchMaterial(name);
        return material == null || !material.isItem() ? null : new ItemStack(material);
    }

    private String groupForWorld(String world) { return getConfig().getString("worlds." + world); }
    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text); }
    private void logFailure(String action, Exception e) { getLogger().log(Level.SEVERE, "Gagal melakukan " + action + ". Jangan hapus file database.", e); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("gis.admin")) { sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cNo permission"))); return true; }
        if (args.length == 0) { sender.sendMessage(color("&e/gis reload | status <player> | save <player> | restore <player> | setworld <world> <group>")); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> { reloadConfig(); sender.sendMessage(color("&aConfig GrandInventorySystem dimuat ulang.")); }
            case "status" -> {
                if (args.length < 2) return usage(sender);
                Player target = getServer().getPlayerExact(args[1]); if (target == null) { sender.sendMessage(color("&cPlayer harus online.")); return true; }
                sender.sendMessage(color("&e" + target.getName() + " &7world=&f" + target.getWorld().getName() + " &7group=&f" + activeGroups.getOrDefault(target.getUniqueId(), "unknown")));
            }
            case "save" -> {
                if (args.length < 2) return usage(sender);
                Player target = getServer().getPlayerExact(args[1]); if (target == null) { sender.sendMessage(color("&cPlayer harus online.")); return true; }
                saveCurrent(target); sender.sendMessage(color("&aSnapshot disimpan untuk " + target.getName()));
            }
            case "restore" -> {
                if (args.length < 2) return usage(sender);
                Player target = getServer().getPlayerExact(args[1]); if (target == null) { sender.sendMessage(color("&cPlayer harus online.")); return true; }
                try { InventorySnapshot snapshot = store.load(target.getUniqueId(), "survival"); if (snapshot == null) sender.sendMessage(color("&cBackup survival tidak ditemukan.")); else { apply(target, snapshot); activeGroups.put(target.getUniqueId(), "survival"); store.setCurrentGroup(target.getUniqueId(), "survival"); sender.sendMessage(color("&aInventory survival dipulihkan. Pastikan player berada di world survival.")); } }
                catch (Exception e) { logFailure("manual restore", e); sender.sendMessage(color("&cGagal restore. Periksa console.")); }
            }
            case "setworld" -> {
                if (args.length < 3) return usage(sender);
                if (!getConfig().isConfigurationSection("groups." + args[2])) { sender.sendMessage(color("&cGroup tidak ditemukan di groups.")); return true; }
                getConfig().set("worlds." + args[1], args[2]); saveConfig(); sender.sendMessage(color("&aWorld " + args[1] + " dipetakan ke group " + args[2]));
            }
            default -> usage(sender);
        }
        return true;
    }

    private boolean usage(CommandSender sender) { sender.sendMessage(color("&e/gis reload | status <player> | save <player> | restore <player> | setworld <world> <group>")); return true; }
}

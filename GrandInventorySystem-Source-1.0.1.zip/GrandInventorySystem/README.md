# Grand Inventory System 1.0.1 (source)

Target: Paper 1.21.3, Java 21, EssentialsX + Multiverse-Core. Geyser players are supported through the normal Bukkit player/inventory API.

## Important behavior
- `NORMAL` (Survival): persistent inventory, armor/offhand and XP snapshot.
- `EMPTY` (City/School): cleared on entry and never persisted.
- `KIT` (PvP): kit is freshly granted on entry and never persisted.
- All Bukkit teleports are detected, including EssentialsX `/warp` and Multiverse teleports. No command hook is required.
- World mapping is based on the actual Bukkit world name, NOT the EssentialsX warp label.

## Setup
1. Stop the server and back up `world/`, `plugins/`, and player data.
2. Build with Java 21 and Maven: `mvn clean package`.
3. Copy `target/grand-inventory-system-1.0.1.jar` into `plugins/` and start once.
4. Run `/mv list` in console. Copy the exact world names into `plugins/GrandInventorySystem/config.yml`.
5. Example mapping (change names to match `/mv list`):

```yaml
worlds:
  world: survival
  city_world: city
  school_world: sekolah
  pvp_world: pvp
```

6. Restart the server. Test with a non-admin account before opening to players.

## Commands
- `/gis reload`
- `/gis status <player>`
- `/gis save <player>`
- `/gis restore <player>`
- `/gis setworld <world> <group>`

Permission: `gis.admin` (default OP).

## Safety notes
- The plugin switches groups after an accepted Bukkit teleport. EssentialsX warps and Multiverse teleports both use Bukkit teleport events.
- First-time entry to a `NORMAL` world preserves the inventory loaded by Paper and creates its first snapshot; it does not wipe it.
- EMPTY and KIT groups are intentionally disposable. Do not configure the same world as both Survival and an isolated area.
- Test death, reconnect, server stop/start, and all warp routes on a backup/test server first. A hard power loss at arbitrary points cannot be guaranteed safe without testing the host's filesystem/database durability.
- This is a source package, not a precompiled JAR. The build requires Maven and internet access to download Paper/SQLite dependencies.

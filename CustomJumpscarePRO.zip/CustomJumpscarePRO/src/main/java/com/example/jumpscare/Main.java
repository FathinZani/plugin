package com.example.jumpscare;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.Style;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.UUID;

public final class Main extends JavaPlugin implements CommandExecutor {

    private static final String GLYPH_SCARE = "\uE000";
    private static final String GLYPH_SCARE2 = "\uE001";
    private static final Key FONT_SCARE = Key.key("jumpscare", "scare");

    @Override
    public void onEnable() {
        if (getCommand("scare") != null) getCommand("scare").setExecutor(this);
        if (getCommand("scare2") != null) getCommand("scare2").setExecutor(this);
        getLogger().info("CustomJumpscare PRO enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("jumpscare.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak memiliki izin.");
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage(ChatColor.YELLOW + "Gunakan: /scare <player> atau /scare2 <player>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Pemain tidak ditemukan atau offline.");
            return true;
        }

        if (command.getName().equalsIgnoreCase("scare")) {
            scare(target);
        } else if (command.getName().equalsIgnoreCase("scare2")) {
            scare2(target);
        }
        sender.sendMessage(ChatColor.GREEN + "Jumpscare dikirim ke " + target.getName() + ".");
        return true;
    }

    private void showImage(Player player, String glyph, long stayTicks) {
        // Requires the supplied resource pack to be installed and accepted by the client.
        Component image = Component.text(glyph).style(Style.style().font(FONT_SCARE).build());
        Title title = Title.title(
                image,
                Component.empty(),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(stayTicks * 50), Duration.ofMillis(250))
        );
        player.showTitle(title);
    }

    private void scare(Player player) {
        player.clearTitle();
        player.playSound(player.getLocation(), Sound.ENTITY_WARDEN_ROAR, 3.0f, 0.65f);
        player.playSound(player.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 2.0f, 0.7f);
        player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 50, 0, false, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 25, 0, false, false, false));

        new BukkitRunnable() {
            @Override public void run() {
                if (!player.isOnline()) return;
                showImage(player, GLYPH_SCARE, 35);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_SCREAM, 3.0f, 0.55f);
            }
        }.runTaskLater(this, 8L);
    }

    private void scare2(Player player) {
        UUID id = player.getUniqueId();
        player.clearTitle();
        player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 120, 0, false, false, false));
        player.playSound(player.getLocation(), Sound.AMBIENT_CAVE, 1.8f, 0.55f);
        player.sendMessage(ChatColor.DARK_RED + "" + ChatColor.BOLD + "[HORROR] " +
                ChatColor.GRAY + "Kamu merasa ada sesuatu yang mengawasimu...");

        new BukkitRunnable() {
            int step = 0;

            @Override public void run() {
                Player target = Bukkit.getPlayer(id);
                if (target == null || !target.isOnline()) {
                    cancel();
                    return;
                }

                switch (step) {
                    case 0 -> {
                        target.sendTitle(ChatColor.DARK_GRAY + " ", ChatColor.GRAY + "Jangan menoleh...", 0, 25, 5);
                        target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_STARE, 2.0f, 0.6f);
                    }
                    case 1 -> {
                        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 35, 0, false, false, false));
                        target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 2.5f, 0.6f);
                    }
                    case 2 -> {
                        showImage(target, GLYPH_SCARE2, 48);
                        target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_ROAR, 4.0f, 0.5f);
                        target.playSound(target.getLocation(), Sound.ENTITY_WITHER_SPAWN, 2.5f, 0.65f);
                    }
                    case 3 -> {
                        target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 4.0f, 0.55f);
                        target.sendTitle(ChatColor.DARK_RED + "" + ChatColor.BOLD + "YOU CANNOT ESCAPE",
                                ChatColor.RED + "It knows where you are.", 0, 35, 10);
                    }
                    default -> cancel();
                }
                step++;
            }
        }.runTaskTimer(this, 20L, 20L);
    }
}

# CustomJumpscare PRO 3.0

Target: Paper 1.21.3, Java 21.

## Build
Run:
```bash
mvn clean package
```
The plugin JAR will be in `target/customjumpscare-3.0.0.jar`.

## Install
1. Copy the JAR into the Paper server's `plugins/` folder.
2. Restart the server.
3. Install/serve the resource pack in `resourcepack/` to Java clients.
4. Players must accept the resource pack for the custom image glyphs to render.
5. Use `/scare <player>` or `/scare2 <player>`.

## Commands
- `/scare <player>`: short image jumpscare.
- `/scare2 <player>`: staged horror sequence.
- Permission: `jumpscare.admin` (default: op).

## Important compatibility note
The plugin uses a Java resource-pack bitmap font glyph rendered in the title area. It is not a guaranteed true edge-to-edge fullscreen overlay; the exact visible size depends on client GUI scale and font rendering. The included pack is a Java resource pack. Geyser does not automatically translate Java bitmap-font glyphs into Bedrock UI, so Bedrock players will receive the sounds/effects but may not see the custom image. A separate Bedrock resource pack/UI implementation is required for reliable Bedrock image overlays.

For public servers, host the resource pack ZIP over HTTPS and configure it as the server resource pack. The ZIP must contain `pack.mcmeta` at its root.

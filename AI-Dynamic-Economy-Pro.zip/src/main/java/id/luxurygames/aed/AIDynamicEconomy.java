package id.luxurygames.aed;

import id.luxurygames.aed.command.AeeCommand;
import id.luxurygames.aed.market.MarketEngine;
import id.luxurygames.aed.persistence.MarketRepository;
import id.luxurygames.aed.shop.ShopPriceService;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;

public final class AIDynamicEconomy extends JavaPlugin {

    private MarketRepository repository;
    private MarketEngine marketEngine;
    private ShopPriceService shopPriceService;

    private boolean paused;

    @Override
    public void onEnable() {

        saveDefaultConfig();

        // Initialize database and market services
        try {
            repository = new MarketRepository(this);
            shopPriceService = new ShopPriceService(this, repository);
            marketEngine = new MarketEngine(this, repository);

        } catch (SQLException ex) {

            getLogger().severe(
                    "Failed to initialize database: " + ex.getMessage()
            );

            ex.printStackTrace();

            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // EconomyShopGUI integration
        boolean esguiEnabled =
                getConfig().getBoolean(
                        "integration.economyshopgui.enabled",
                        true
                );

        if (esguiEnabled &&
                Bukkit.getPluginManager().getPlugin("EconomyShopGUI") != null) {

            Bukkit.getPluginManager().registerEvents(marketEngine, this);

            getLogger().info(
                    "EconomyShopGUI detected. Market integration enabled."
            );

        } else {

            getLogger().warning(
                    "EconomyShopGUI integration is disabled or plugin was not detected."
            );
        }

        // Register commands
        AeeCommand commandExecutor = new AeeCommand(this);

        PluginCommand aeeCommand = getCommand("aee");

        if (aeeCommand == null) {

            getLogger().severe(
                    "Command 'aee' is missing from plugin.yml!"
            );

            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        aeeCommand.setExecutor(commandExecutor);
        aeeCommand.setTabCompleter(commandExecutor);

        // Startup market update
        long delay = Math.max(
                1,
                getConfig().getLong("core.update-delay-ticks", 80)
        );

        if (getConfig().getBoolean("core.update-on-startup", true)) {

            Bukkit.getScheduler().runTaskLater(
                    this,
                    () -> {
                        if (isEngineEnabled() && !paused) {
                            runMarketUpdate();
                        }
                    },
                    delay
            );
        }

        // Periodic database flush
        long flushInterval = Math.max(
                10,
                getConfig().getLong(
                        "storage.flush-interval-seconds",
                        30
                )
        );

        Bukkit.getScheduler().runTaskTimerAsynchronously(
                this,
                () -> {

                    if (repository == null) return;

                    try {
                        repository.flush();

                    } catch (SQLException ex) {

                        getLogger().warning(
                                "Database flush failed: " + ex.getMessage()
                        );
                    }

                },
                flushInterval * 20L,
                flushInterval * 20L
        );

        getLogger().info("--------------------------------");
        getLogger().info(" AI Dynamic Economy enabled!");
        getLogger().info(" Version: " + getDescription().getVersion());
        getLogger().info(" Platform: Paper 1.21.3");
        getLogger().info(" Storage: SQLite");
        getLogger().info("--------------------------------");
    }

    /**
     * Execute dynamic market price update.
     */
    public void runMarketUpdate() {

        if (!isEngineEnabled() || paused) {
            return;
        }

        var signals = marketEngine.snapshotSignals();

        Bukkit.getScheduler().runTaskAsynchronously(
                this,
                () -> {

                    try {

                        var result =
                                shopPriceService.applyMarketPrices(signals);

                        Bukkit.getScheduler().runTask(
                                this,
                                () -> {

                                    if (result.updatedFiles() > 0
                                            && getConfig().getBoolean(
                                            "integration.economyshopgui.reload-after-price-update",
                                            true
                                    )) {

                                        String reloadCommand =
                                                getConfig().getString(
                                                        "integration.economyshopgui.reload-command",
                                                        "sreload"
                                                );

                                        if (reloadCommand != null
                                                && !reloadCommand.isBlank()) {

                                            Bukkit.dispatchCommand(
                                                    Bukkit.getConsoleSender(),
                                                    reloadCommand
                                            );
                                        }
                                    }

                                    getLogger().info(
                                            "Market update completed: "
                                                    + result.updatedItems()
                                                    + " items, "
                                                    + result.updatedFiles()
                                                    + " files."
                                    );
                                }
                        );

                    } catch (Exception ex) {

                        getLogger().severe(
                                "Market update failed: " + ex.getMessage()
                        );

                        ex.printStackTrace();
                    }
                }
        );
    }

    /**
     * Reload plugin configuration.
     */
    public void reloadPluginConfig() {
        reloadConfig();
    }

    /**
     * Check whether the main economy engine is enabled.
     */
    public boolean isEngineEnabled() {
        return getConfig().getBoolean("core.enabled", true);
    }

    public boolean isPaused() {
        return paused;
    }

    public void setPaused(boolean value) {
        this.paused = value;
    }

    public MarketRepository repository() {
        return repository;
    }

    public MarketEngine marketEngine() {
        return marketEngine;
    }

    public ShopPriceService shopPriceService() {
        return shopPriceService;
    }

    @Override
    public void onDisable() {

        getLogger().info("Shutting down AI Dynamic Economy...");

        if (repository != null) {

            try {

                repository.flush();
                repository.close();

                getLogger().info(
                        "Database successfully closed."
                );

            } catch (SQLException ex) {

                getLogger().severe(
                        "Could not close database cleanly: "
                                + ex.getMessage()
                );

                ex.printStackTrace();
            }
        }

        getLogger().info("AI Dynamic Economy disabled.");
    }
}
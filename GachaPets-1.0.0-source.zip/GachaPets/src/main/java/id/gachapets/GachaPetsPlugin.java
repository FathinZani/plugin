package id.gachapets;

import com.petsplugin.PetsPlugin;
import com.petsplugin.model.PetInstance;
import com.petsplugin.model.PetType;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public final class GachaPetsPlugin extends JavaPlugin implements Listener {
    private Economy economy;
    private PetsPlugin babyPets;
    private final Random random = new Random();
    private final Set<UUID> rolling = new HashSet<>();
    private final Map<UUID, String> pending = new HashMap<>();
    private static final String[] RARITIES = {"common", "uncommon", "rare", "epic", "legendary"};

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!(Bukkit.getPluginManager().getPlugin("BabyPets") instanceof PetsPlugin pets)) {
            getLogger().severe("BabyPets 1.3.1 tidak ditemukan. GachaPets dinonaktifkan.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        babyPets = pets;
        RegisteredServiceProvider<Economy> provider = getServer().getServicesManager().getRegistration(Economy.class);
        if (provider == null) {
            getLogger().severe("Vault economy provider tidak ditemukan. Pastikan plugin ekonomi aktif.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        economy = provider.getProvider();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("gachapets")).setExecutor(this::onCommand);
        getLogger().info("GachaPets 1.0.0 aktif; integrasi BabyPets 1.3.1 berhasil.");
    }

    private boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Command ini hanya untuk pemain."); return true; }
        if (!player.hasPermission("gachapets.use")) { player.sendMessage(color("&cKamu tidak punya izin.")); return true; }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload") && player.hasPermission("gachapets.admin")) {
            reloadConfig(); player.sendMessage(color("&aKonfigurasi GachaPets dimuat ulang.")); return true;
        }
        openMenu(player);
        return true;
    }

    private void openMenu(Player player) {
        Inventory inv = Bukkit.createInventory(new GachaHolder(), 27, color("&8Pet Gacha Roulette"));
        for (int i = 0; i < 27; i++) inv.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, " "));
        Material[] icons = {Material.EGG, Material.EXPERIENCE_BOTTLE, Material.DIAMOND, Material.AMETHYST_SHARD, Material.NETHER_STAR};
        int[] slots = {10, 11, 12, 13, 14};
        for (int i = 0; i < RARITIES.length; i++) {
            String rarity = RARITIES[i];
            double price = getConfig().getDouble("prices." + rarity, 1000);
            inv.setItem(slots[i], item(icons[i], "&f&l" + rarity.toUpperCase() + " GACHA",
                    "&7Harga: &a$" + String.format(Locale.US, "%,.0f", price), "", "&eKlik untuk memulai roulette!"));
        }
        inv.setItem(16, item(Material.CHEST, "&b&lKOLEKSI PET", "&7Buka koleksi Baby Pets.", "", "&eKlik untuk membuka /pets"));
        inv.setItem(22, item(Material.BOOK, "&bInformasi Peluang", "&785% rarity pilihan pada tier awal,", "&7peluang sisanya menuju tier lebih tinggi."));
        player.openInventory(inv);
    }

    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof GachaHolder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || event.getClickedInventory() != event.getView().getTopInventory()) return;
        int slot = event.getRawSlot();
        if (slot >= 10 && slot <= 14) startRoll(player, RARITIES[slot - 10]);
        else if (slot == 16) { player.closeInventory(); player.performCommand("pets"); }
    }

    @EventHandler public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GachaHolder) event.setCancelled(true);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        // Roll is completed from UUID even if the player disconnects; do not cancel a paid transaction.
    }

    private void startRoll(Player player, String requested) {
        UUID uuid = player.getUniqueId();
        if (!rolling.add(uuid)) { player.sendMessage(color("&cRoulette kamu masih berjalan.")); return; }
        double price = getConfig().getDouble("prices." + requested, -1);
        if (price < 0 || !economy.has(player, price)) {
            rolling.remove(uuid); player.sendMessage(color("&cSaldo kamu tidak cukup.")); return;
        }
        String rarity = rollRarity(requested);
        List<String> pets = getConfig().getStringList("pets." + rarity);
        if (pets.isEmpty()) { rolling.remove(uuid); player.sendMessage(color("&cDaftar pet rarity ini kosong. Hubungi admin.")); return; }
        String petId = pets.get(random.nextInt(pets.size())).toLowerCase(Locale.ROOT);
        PetType petType = babyPets.getPetTypes().get(petId);
        if (petType == null) {
            rolling.remove(uuid); player.sendMessage(color("&cID pet '" + petId + "' tidak ditemukan di BabyPets. Uang tidak dipotong.")); return;
        }
        if (!economy.withdrawPlayer(player, price).transactionSuccess()) {
            rolling.remove(uuid); player.sendMessage(color("&cPembayaran gagal. Coba lagi.")); return;
        }
        pending.put(uuid, petId);
        Inventory roulette = Bukkit.createInventory(new GachaHolder(), 27, color("&8&lPET ROULETTE"));
        for (int i = 0; i < 27; i++) roulette.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, " "));
        player.openInventory(roulette);
        List<String> preview = new ArrayList<>();
        for (String tier : RARITIES) preview.addAll(getConfig().getStringList("pets." + tier));
        if (preview.isEmpty()) preview.add(petId);

        new BukkitRunnable() {
            int tick = 0;
            int interval = Math.max(1, getConfig().getInt("roulette.starting-interval-ticks", 2));
            @Override public void run() {
                Player online = Bukkit.getPlayer(uuid);
                if (online != null && online.isOnline() && online.getOpenInventory().getTopInventory().getHolder() instanceof GachaHolder) {
                    String shown = preview.get(random.nextInt(preview.size()));
                    online.getOpenInventory().getTopInventory().setItem(13, item(Material.PAPER, "&b&l" + shown.toUpperCase(Locale.ROOT)));
                    online.playSound(online.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.2f + Math.min(tick, 15) * 0.035f);
                }
                tick += interval;
                interval = Math.min(getConfig().getInt("roulette.ending-interval-ticks", 10), interval + 1);
                if (tick >= getConfig().getInt("roulette.duration-ticks", 80)) {
                    cancel();
                    completeRoll(uuid, player.getName(), rarity, petId, price);
                }
            }
        }.runTaskTimer(this, 0L, 2L);
    }

    private void completeRoll(UUID uuid, String playerName, String rarity, String petId, double price) {
        Player player = Bukkit.getPlayer(uuid);
        try {
            PetType type = babyPets.getPetTypes().get(petId);
            if (type == null) throw new IllegalStateException("Pet type no longer exists: " + petId);
            PetInstance instance = PetInstance.createNew(uuid, type.getId());
            babyPets.getPetManager().ensurePersistentAppearance(instance, type);
            int insertedId = babyPets.getDatabaseManager().insertPet(instance);
            if (insertedId <= 0) throw new IllegalStateException("BabyPets database insert failed");
            babyPets.getPetManager().refreshCache(uuid);
            if (player != null && player.isOnline()) {
                player.sendMessage(color("&8&m------------------------------"));
                player.sendMessage(color("&b&lGACHAPETS RESULT"));
                player.sendMessage(color("&7Pet: &f" + type.getDisplayName()));
                player.sendMessage(color("&7Rarity: " + rarityColor(rarity) + rarity.toUpperCase(Locale.ROOT)));
                player.sendMessage(color("&aPet berhasil ditambahkan ke koleksi!"));
                player.sendMessage(color("&8&m------------------------------"));
                player.playSound(player.getLocation(), rarity.equals("legendary") ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                player.closeInventory();
            }
            if (rarity.equals("legendary")) {
                Bukkit.broadcastMessage(color("&6&l✦ LEGENDARY PET ✦"));
                Bukkit.broadcastMessage(color("&e" + playerName + " &7mendapatkan pet &6&l" + type.getDisplayName() + "&7!"));
                for (Player online : Bukkit.getOnlinePlayers()) online.playSound(online.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            }
        } catch (Exception ex) {
            getLogger().severe("Gagal memberikan pet " + petId + " kepada " + playerName + ": " + ex.getMessage());
            if (player != null && player.isOnline()) player.sendMessage(color("&cGacha gagal menyimpan pet. Saldo dikembalikan."));
            // Refund to the online player. If offline, queue it for the next login via a persisted pending refund.
            if (player != null && player.isOnline()) economy.depositPlayer(player, price);
            else {
                getConfig().set("pending-refunds." + uuid, getConfig().getDouble("pending-refunds." + uuid, 0) + price);
                saveConfig();
            }
        } finally {
            pending.remove(uuid);
            rolling.remove(uuid);
        }
    }

    @EventHandler public void onJoin(org.bukkit.event.player.PlayerJoinEvent event) {
        String path = "pending-refunds." + event.getPlayer().getUniqueId();
        double refund = getConfig().getDouble(path, 0);
        if (refund > 0) {
            economy.depositPlayer(event.getPlayer(), refund);
            getConfig().set(path, null); saveConfig();
            event.getPlayer().sendMessage(color("&aSaldo gacha sebesar $" + String.format(Locale.US, "%,.0f", refund) + " telah dikembalikan."));
        }
    }

    private String rollRarity(String requested) {
        var section = getConfig().getConfigurationSection("chances." + requested);
        if (section == null) return requested;
        int roll = random.nextInt(10000) + 1;
        int cumulative = 0;
        for (String rarity : RARITIES) {
            if (!section.contains(rarity)) continue;
            cumulative += section.getInt(rarity);
            if (roll <= cumulative) return rarity;
        }
        return requested;
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        if (lore.length > 0) meta.setLore(Arrays.stream(lore).map(this::color).toList());
        stack.setItemMeta(meta);
        return stack;
    }
    private String rarityColor(String rarity) {
        return switch (rarity) { case "common" -> "&a"; case "uncommon" -> "&e"; case "rare" -> "&b"; case "epic" -> "&d"; default -> "&6"; };
    }
    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text); }
    private static final class GachaHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
}

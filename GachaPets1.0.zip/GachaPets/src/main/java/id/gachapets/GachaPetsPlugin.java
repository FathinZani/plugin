package id.gachapets;

import com.petsplugin.PetsPlugin;
import com.petsplugin.model.PetInstance;
import com.petsplugin.model.PetType;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public final class GachaPetsPlugin extends JavaPlugin implements Listener {

    private Economy economy;
    private PetsPlugin babyPets;

    private final Random random = new Random();

    private final Set<UUID> rolling = new HashSet<>();

    private static final String[] RARITIES = {
            "common",
            "uncommon",
            "rare",
            "epic",
            "legendary"
    };

    private static final Material[] RARITY_ICONS = {
            Material.EGG,
            Material.EXPERIENCE_BOTTLE,
            Material.DIAMOND,
            Material.AMETHYST_SHARD,
            Material.NETHER_STAR
    };

    private static final int[] RARITY_SLOTS = {
            10, 11, 12, 13, 14
    };

    @Override
    public void onEnable() {

        saveDefaultConfig();

        // BabyPets dependency
        if (!(Bukkit.getPluginManager().getPlugin("BabyPets")
                instanceof PetsPlugin pets)) {

            getLogger().severe(
                    "BabyPets 1.3.1 tidak ditemukan!"
            );

            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        babyPets = pets;

        // Vault economy
        RegisteredServiceProvider<Economy> provider =
                getServer().getServicesManager()
                        .getRegistration(Economy.class);

        if (provider == null) {

            getLogger().severe(
                    "Vault economy provider tidak ditemukan!"
            );

            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        economy = provider.getProvider();

        // Register events
        Bukkit.getPluginManager().registerEvents(this, this);

        // Register command
        if (getCommand("gachapets") == null) {

            getLogger().severe(
                    "Command gachapets tidak ditemukan di plugin.yml!"
            );

            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        Objects.requireNonNull(
                getCommand("gachapets")
        ).setExecutor(this::onCommand);

        getLogger().info("--------------------------------");
        getLogger().info("GachaPets 1.0.1 berhasil aktif!");
        getLogger().info("BabyPets integration: SUCCESS");
        getLogger().info("Vault integration: SUCCESS");
        getLogger().info("--------------------------------");
    }

    @Override
    public void onDisable() {
        rolling.clear();
        getLogger().info("GachaPets dinonaktifkan.");
    }

    // =====================================================
    // COMMAND
    // =====================================================

    public boolean onCommand(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {

        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {

            if (!sender.hasPermission("gachapets.admin")) {
                sender.sendMessage(color("&cKamu tidak memiliki izin."));
                return true;
            }

            reloadConfig();

            sender.sendMessage(
                    color("&aKonfigurasi GachaPets berhasil dimuat ulang!")
            );

            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Command ini hanya bisa digunakan pemain.");
            return true;
        }

        if (!player.hasPermission("gachapets.use")) {
            player.sendMessage(color("&cKamu tidak memiliki izin."));
            return true;
        }

        openMenu(player);

        return true;
    }

    // =====================================================
    // MAIN GUI
    // =====================================================

    private void openMenu(Player player) {

        Inventory inv = createMenu(
                "&8Pet Gacha Roulette",
                27
        );

        for (int i = 0; i < 27; i++) {
            inv.setItem(
                    i,
                    item(Material.BLACK_STAINED_GLASS_PANE, " ")
            );
        }

        for (int i = 0; i < RARITIES.length; i++) {

            String rarity = RARITIES[i];

            double price = getConfig().getDouble(
                    "prices." + rarity,
                    1000
            );

            inv.setItem(
                    RARITY_SLOTS[i],
                    item(
                            RARITY_ICONS[i],
                            rarityColor(rarity) + "&l"
                                    + rarity.toUpperCase(Locale.ROOT),

                            "&7Harga: &a$"
                                    + String.format(Locale.US, "%,.0f", price),

                            "",

                            "&eKlik untuk memulai roulette!"
                    )
            );
        }

        inv.setItem(
                16,
                item(
                        Material.CHEST,
                        "&b&lKOLEKSI PET",
                        "&7Buka koleksi Baby Pets.",
                        "",
                        "&eKlik untuk membuka koleksi!"
                )
        );

        inv.setItem(
                22,
                item(
                        Material.BOOK,
                        "&b&lINFORMASI GACHA",
                        "&7Pilih rarity yang ingin kamu coba.",
                        "&7Pet akan otomatis masuk koleksi BabyPets.",
                        "",
                        "&eSelamat mencoba!"
                )
        );

        player.openInventory(inv);
    }

    // =====================================================
    // INVENTORY EVENTS
    // =====================================================

    @EventHandler
    public void onClick(InventoryClickEvent event) {

        if (!(event.getView().getTopInventory()
                .getHolder() instanceof GachaHolder)) {
            return;
        }

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (event.getClickedInventory() !=
                event.getView().getTopInventory()) {
            return;
        }

        int slot = event.getRawSlot();

        for (int i = 0; i < RARITY_SLOTS.length; i++) {

            if (slot == RARITY_SLOTS[i]) {
                startRoll(player, RARITIES[i]);
                return;
            }
        }

        if (slot == 16) {

            player.closeInventory();
            player.performCommand("pets");

        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {

        if (event.getView().getTopInventory()
                .getHolder() instanceof GachaHolder) {

            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Roulette tetap diselesaikan meskipun pemain disconnect.
    }

    // =====================================================
    // ROULETTE
    // =====================================================

    private void startRoll(Player player, String requested) {

        UUID uuid = player.getUniqueId();

        if (!rolling.add(uuid)) {

            player.sendMessage(
                    color("&cRoulette kamu masih berjalan!")
            );

            return;
        }

        double price = getConfig().getDouble(
                "prices." + requested,
                -1
        );

        if (!Double.isFinite(price) || price < 0) {

            rolling.remove(uuid);

            player.sendMessage(
                    color("&cHarga gacha tidak valid.")
            );

            return;
        }

        if (!economy.has(player, price)) {

            rolling.remove(uuid);

            player.sendMessage(
                    color("&cSaldo kamu tidak cukup!")
            );

            return;
        }

        String rarity = rollRarity(requested);

        List<String> pets = getConfig().getStringList(
                "pets." + rarity
        );

        if (pets.isEmpty()) {

            rolling.remove(uuid);

            player.sendMessage(
                    color("&cDaftar pet rarity ini kosong!")
            );

            return;
        }

        String petId = pets.get(
                random.nextInt(pets.size())
        ).toLowerCase(Locale.ROOT);

        PetType petType = babyPets.getPetTypes().get(petId);

        if (petType == null) {

            rolling.remove(uuid);

            player.sendMessage(
                    color("&cPet ID '" + petId + "' tidak ditemukan!")
            );

            return;
        }

        // Withdraw payment
        EconomyResponse response = economy.withdrawPlayer(
                player,
                price
        );

        if (!response.transactionSuccess()) {

            rolling.remove(uuid);

            player.sendMessage(
                    color("&cPembayaran gagal!")
            );

            return;
        }

        Inventory roulette = createMenu(
                "&8&lPET ROULETTE",
                27
        );

        for (int i = 0; i < 27; i++) {

            roulette.setItem(
                    i,
                    item(Material.BLACK_STAINED_GLASS_PANE, " ")
            );
        }

        roulette.setItem(
                13,
                item(
                        Material.NETHER_STAR,
                        "&b&lROLLING..."
                )
        );

        player.openInventory(roulette);

        List<String> preview = new ArrayList<>();

        for (String tier : RARITIES) {

            preview.addAll(
                    getConfig().getStringList("pets." + tier)
            );
        }

        if (preview.isEmpty()) {
            preview.add(petId);
        }

        int duration = Math.max(
                20,
                getConfig().getInt(
                        "roulette.duration-ticks",
                        80
                )
        );

        new BukkitRunnable() {

            int elapsed = 0;
            int nextUpdate = 0;
            int interval = Math.max(
                    1,
                    getConfig().getInt(
                            "roulette.starting-interval-ticks",
                            2
                    )
            );

            @Override
            public void run() {

                elapsed++;

                Player online = Bukkit.getPlayer(uuid);

                if (online != null && online.isOnline()) {

                    if (elapsed >= nextUpdate &&
                            online.getOpenInventory()
                                    .getTopInventory()
                                    .getHolder() instanceof GachaHolder) {

                        String shown = preview.get(
                                random.nextInt(preview.size())
                        );

                        online.getOpenInventory()
                                .getTopInventory()
                                .setItem(
                                        13,
                                        item(
                                                Material.PAPER,
                                                "&b&l" + shown.toUpperCase(
                                                        Locale.ROOT
                                                )
                                        )
                                );

                        online.playSound(
                                online.getLocation(),
                                Sound.UI_BUTTON_CLICK,
                                0.7f,
                                1.2f
                        );

                        nextUpdate = elapsed + interval;

                        interval = Math.min(
                                12,
                                interval + 1
                        );
                    }
                }

                if (elapsed >= duration) {

                    cancel();

                    completeRoll(
                            uuid,
                            player.getName(),
                            rarity,
                            petId,
                            price
                    );
                }
            }

        }.runTaskTimer(this, 0L, 1L);
    }

    // =====================================================
    // COMPLETE ROLL
    // =====================================================

    private void completeRoll(
            UUID uuid,
            String playerName,
            String rarity,
            String petId,
            double price
    ) {

        Player player = Bukkit.getPlayer(uuid);

        try {

            PetType type = babyPets.getPetTypes().get(petId);

            if (type == null) {
                throw new IllegalStateException(
                        "Pet type tidak ditemukan: " + petId
                );
            }

            PetInstance instance = PetInstance.createNew(
                    uuid,
                    type.getId()
            );

            babyPets.getPetManager()
                    .ensurePersistentAppearance(instance, type);

            int insertedId = babyPets.getDatabaseManager()
                    .insertPet(instance);

            if (insertedId <= 0) {
                throw new IllegalStateException(
                        "Database gagal menyimpan pet."
                );
            }

            babyPets.getPetManager().refreshCache(uuid);

            if (player != null && player.isOnline()) {

                player.sendMessage(color(
                        "&8&m------------------------------"
                ));

                player.sendMessage(
                        color("&b&lGACHAPETS RESULT")
                );

                player.sendMessage(
                        color("&7Pet: &f" + type.getDisplayName())
                );

                player.sendMessage(
                        color(
                                "&7Rarity: "
                                        + rarityColor(rarity)
                                        + rarity.toUpperCase(Locale.ROOT)
                        )
                );

                player.sendMessage(
                        color("&aPet berhasil ditambahkan ke koleksi!")
                );

                player.sendMessage(color(
                        "&8&m------------------------------"
                ));

                player.playSound(
                        player.getLocation(),
                        rarity.equals("legendary")
                                ? Sound.UI_TOAST_CHALLENGE_COMPLETE
                                : Sound.ENTITY_PLAYER_LEVELUP,
                        1f,
                        1f
                );

                player.closeInventory();
            }

            // Legendary announcement
            if (rarity.equals("legendary")) {

                Bukkit.broadcastMessage(
                        color("&6&l✦ LEGENDARY PET ✦")
                );

                Bukkit.broadcastMessage(
                        color(
                                "&e" + playerName
                                        + " &7mendapatkan pet &6&l"
                                        + type.getDisplayName()
                                        + "&7!"
                        )
                );

                for (Player online : Bukkit.getOnlinePlayers()) {

                    online.playSound(
                            online.getLocation(),
                            Sound.UI_TOAST_CHALLENGE_COMPLETE,
                            1f,
                            1f
                    );
                }
            }

        } catch (Exception ex) {

            getLogger().severe(
                    "Gagal memberikan pet kepada "
                            + playerName
                            + ": "
                            + ex.getMessage()
            );

            refund(uuid, price);

            if (player != null && player.isOnline()) {

                player.sendMessage(
                        color("&cGacha gagal. Saldo kamu dikembalikan.")
                );
            }

        } finally {

            rolling.remove(uuid);
        }
    }

    // =====================================================
    // REFUND SYSTEM
    // =====================================================

    private void refund(UUID uuid, double amount) {

        Player player = Bukkit.getPlayer(uuid);

        try {

            if (player != null && player.isOnline()) {

                EconomyResponse response = economy.depositPlayer(
                        player,
                        amount
                );

                if (response.transactionSuccess()) {
                    return;
                }
            }

            // Queue refund for offline player
            String path = "pending-refunds." + uuid;

            double current = getConfig().getDouble(path, 0);

            getConfig().set(
                    path,
                    current + amount
            );

            saveConfig();

        } catch (Exception ex) {

            getLogger().severe(
                    "Refund gagal untuk " + uuid + ": "
                            + ex.getMessage()
            );
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {

        Player player = event.getPlayer();

        String path = "pending-refunds."
                + player.getUniqueId();

        double refund = getConfig().getDouble(path, 0);

        if (refund <= 0) {
            return;
        }

        EconomyResponse response = economy.depositPlayer(
                player,
                refund
        );

        if (response.transactionSuccess()) {

            getConfig().set(path, null);
            saveConfig();

            player.sendMessage(
                    color(
                            "&aSaldo gacha sebesar $"
                                    + String.format(
                                            Locale.US,
                                            "%,.0f",
                                            refund
                                    )
                                    + " berhasil dikembalikan."
                    )
            );
        }
    }

    // =====================================================
    // RARITY SYSTEM
    // =====================================================

    private String rollRarity(String requested) {

        var section = getConfig()
                .getConfigurationSection(
                        "chances." + requested
                );

        if (section == null) {
            return requested;
        }

        int roll = random.nextInt(10000) + 1;

        int cumulative = 0;

        for (String rarity : RARITIES) {

            if (!section.contains(rarity)) {
                continue;
            }

            cumulative += Math.max(
                    0,
                    section.getInt(rarity)
            );

            if (roll <= cumulative) {
                return rarity;
            }
        }

        return requested;
    }

    // =====================================================
    // GUI UTILITIES
    // =====================================================

    private Inventory createMenu(String title, int size) {

        GachaHolder holder = new GachaHolder();

        Inventory inventory = Bukkit.createInventory(
                holder,
                size,
                color(title)
        );

        holder.setInventory(inventory);

        return inventory;
    }

    private ItemStack item(
            Material material,
            String name,
            String... lore
    ) {

        ItemStack stack = new ItemStack(material);

        ItemMeta meta = stack.getItemMeta();

        if (meta == null) {
            return stack;
        }

        meta.setDisplayName(color(name));

        if (lore.length > 0) {

            meta.setLore(
                    Arrays.stream(lore)
                            .map(this::color)
                            .toList()
            );
        }

        stack.setItemMeta(meta);

        return stack;
    }

    // =====================================================
    // COLOR UTILITIES
    // =====================================================

    private String rarityColor(String rarity) {

        return switch (rarity.toLowerCase(Locale.ROOT)) {

            case "common" -> "&a";
            case "uncommon" -> "&e";
            case "rare" -> "&b";
            case "epic" -> "&d";
            case "legendary" -> "&6";

            default -> "&f";
        };
    }

    private String color(String text) {

        return ChatColor.translateAlternateColorCodes(
                '&',
                text
        );
    }

    // =====================================================
    // INVENTORY HOLDER
    // =====================================================

    private static final class GachaHolder implements InventoryHolder {

        private Inventory inventory;

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
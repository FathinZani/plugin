# GachaPets 1.0.0 (source project)

Plugin target: Paper 1.21.3 / Java 21
Integrations: BabyPets 1.3.1, Vault + economy provider, GeyserMC (Bedrock players use the same server inventory GUI).

## Commands
- `/gachapets` — open gacha menu
- `/gachapets reload` — reload config (requires `gachapets.admin`)

## Install dependencies on the server
1. Paper 1.21.3 running Java 21.
2. BabyPets 1.3.1 (`BabyPets` plugin name).
3. Vault and an economy plugin providing Vault Economy.
4. GeyserMC/Floodgate only if Bedrock crossplay is desired.

## Build
This is a Gradle Java project. With internet access and Gradle 8+, run:

```bash
gradle build
```

The output should be `build/libs/GachaPets-1.0.0.jar`. The build downloads Paper API and Vault API, while BabyPets 1.3.1 is included as a compile-only reference in `libs/`. It is not bundled into GachaPets.jar.

## Important
- Pet IDs are taken from the supplied BabyPets 1.3.1 `pets.yml`: `polar_bear` and `trader_llama` use underscores.
- GachaPets calls BabyPets 1.3.1's public manager/database API to create and persist the pet, then refreshes the player's pet cache.
- A failed database insert triggers a refund. If the player disconnected, the refund is queued in GachaPets config and paid on next login.
- Test on a backup/test server first. This source package has not been compiled or runtime-tested in this environment because dependency repositories are unreachable here.

# AI Dynamic Economy

**Version 2.0.0 · Paper 1.21.3 · Java 21 · EconomyShopGUI Free**

Adaptive market pricing for EconomyShopGUI. This is a deterministic market-analysis plugin, not an external LLM/AI service. It learns from successful shop transactions and applies bounded price changes using an independent BUY and SELL curve.

## Project status

This repository is a professional source project with a Maven build, GitHub Actions, SQLite persistence, tests for the pricing model, and an EconomyShopGUI API integration. It has **not yet been compiled or integration-tested against your exact server build/configuration**. Treat it as a test build until the CI workflow passes and you verify it on a copy of your server.

## Features

- Official `PostTransactionEvent` API listener (no reflection-based event guessing).
- Successful transactions only; BUY and SELL quantities tracked separately.
- SQLite persistence with WAL; activity survives restarts.
- Exponential time decay so old trading activity gradually loses influence.
- Independent buy-price and sell-price calculations.
- Price calculations always reference the first stored baseline, avoiding compounding.
- Configurable maximum movement; default is ±20% from the baseline.
- Disabled/non-positive prices (including `-1`) are preserved.
- Recursive shop YAML scan; timestamped backups before any changed file is saved.
- Config toggles for the engine, tracking, buy/sell pricing, random events, backup and ESGUI reload.
- `/aee info`, `/aee pause`, `/aee resume`, `/aee reload`, `/aee run`, `/aee top`.
- GitHub Actions build artifact and tagged release workflows.

## Build locally

Requirements: JDK 21 and Maven 3.9+.

```bash
mvn -B clean verify
```

The shaded plugin JAR is generated in `target/AI-Dynamic-Economy-2.0.0.jar`.

Windows: run `build.bat`. Linux/macOS: run `./build.sh`.

## GitHub build

1. Create a GitHub repository.
2. Upload the **contents** of this folder to the repository root.
3. Open **Actions → Build** and run the workflow (or push to `main`).
4. Download `AI-Dynamic-Economy-JAR` from the successful workflow run's Artifacts section.
5. For a release, push a tag such as `v2.0.0`; the Release workflow builds and attaches the JAR.

## Installation / safe test

1. Back up your server and `plugins/EconomyShopGUI/` directory.
2. Confirm EconomyShopGUI Free is version 3.9/1.12 or newer (API support is required). The API docs state the API is shared by Free and Premium.
3. Place the JAR in `plugins/` and start the server once to generate `plugins/AIDynamicEconomy/config.yml`.
4. Verify `integration.economyshopgui.shop-directory` points to the actual `shops` folder for your installation.
5. Start with `core.enabled: false` if you only want to inspect setup first. Set it to `true` after validating paths.
6. Test on a staging copy and inspect the generated backups before deploying live.

## Configuration switches

```yaml
core:
  enabled: true
features:
  transaction-tracking: true
  dynamic-buy-prices: true
  dynamic-sell-prices: true
  random-market-events: false
  auto-backup: true
```

Set `core.enabled: false` to disable the engine. Individual features can be switched independently. Run `/aee reload` after editing the config. A server restart is recommended after changing the shop directory or integration settings.

## Market model

For each material, successful buy and sell quantities are stored separately. A logarithmic demand-pressure signal is passed through `tanh`, smoothed, and capped. The BUY curve rises with buy pressure; the SELL curve falls with sell pressure. Every calculation uses a persistent baseline price, not the last modified price, preventing runaway compounding. The default maximum deviation is ±20%.

## Important compatibility notes

- EconomyShopGUI API is declared as `provided`; the API is supplied by EconomyShopGUI at runtime. `softdepend` ensures it loads first.
- The shop scanner currently handles standard scalar `material`/`type`, `buy`, and `sell` item entries. Custom layouts, quoted numeric values, custom item providers, or non-standard price structures may require an adapter.
- Bukkit YAML serialization can normalize formatting/comments when a file is saved. Timestamped backups are created before modifications. Always test with a copy first.
- The configured reload command defaults to `sreload`; verify that command exists in your installed EconomyShopGUI version. Set `reload-after-price-update: false` if your server uses another reload process.
- Do not enable this alongside EconomyShopGUI's own dynamic pricing for the same items unless you intentionally want both systems to interact.
- SQLite writes occur for successful transaction records. Keep the database on local storage, not a network share.

## Commands

| Command | Description |
|---|---|
| `/aee` or `/aee info` | Engine and feature status |
| `/aee pause` | Pause market updates |
| `/aee resume` | Resume market updates |
| `/aee reload` | Reload config |
| `/aee run` | Apply current market calculation |
| `/aee top` | Show top activity materials |

Permission: `aee.admin` (default: op).

## License

MIT. See [LICENSE](LICENSE).

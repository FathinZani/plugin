package id.luxurygames.aed.command;

import id.luxurygames.aed.AIDynamicEconomy;
import id.luxurygames.aed.persistence.MarketRepository;
import org.bukkit.ChatColor;
import org.bukkit.command.*;

import java.sql.SQLException;
import java.util.*;

public final class AeeCommand implements CommandExecutor, TabCompleter {
    private final AIDynamicEconomy plugin;
    public AeeCommand(AIDynamicEconomy plugin) { this.plugin=plugin; }
    private String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("aee.admin")) { sender.sendMessage(c("&cKamu tidak punya izin.")); return true; }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(c("&8&m------------------------------"));
            sender.sendMessage(c("&b&lAI DYNAMIC ECONOMY &7v"+plugin.getDescription().getVersion()));
            sender.sendMessage(c("&7Engine: "+(plugin.isEngineEnabled()?"&aON":"&cOFF")+"  &7Pause: "+(plugin.isPaused()?"&cYES":"&aNO")));
            sender.sendMessage(c("&7Buy: "+plugin.getConfig().getBoolean("features.dynamic-buy-prices")+"  Sell: "+plugin.getConfig().getBoolean("features.dynamic-sell-prices")));
            sender.sendMessage(c("&7Commands: &f/aee pause|resume|reload|run|top"));
            sender.sendMessage(c("&8&m------------------------------")); return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "pause" -> { plugin.setPaused(true); sender.sendMessage(c("&eMarket engine dijeda.")); }
            case "resume" -> { plugin.setPaused(false); sender.sendMessage(c("&aMarket engine dilanjutkan.")); }
            case "reload" -> { plugin.reloadPluginConfig(); sender.sendMessage(c("&aConfig dimuat ulang. Fitur ON/OFF mengikuti config.yml.")); }
            case "run" -> { if (!plugin.isEngineEnabled()) sender.sendMessage(c("&ccore.enabled sedang false di config.yml.")); else { plugin.runMarketUpdate(); sender.sendMessage(c("&aPembaruan pasar dijadwalkan.")); } }
            case "top" -> {
                try {
                    var rows = plugin.marketEngine().snapshotSignals().entrySet().stream()
                            .sorted(Comparator.comparingDouble(e -> -(e.getValue().buyUnits()+e.getValue().sellUnits())))
                            .limit(10).toList();
                    sender.sendMessage(c("&b&lTOP MARKET ACTIVITY"));
                    int i=1; for (var row:rows) sender.sendMessage(c("&7"+(i++)+". &f"+row.getKey()+" &8| &aBuy "+(long)row.getValue().buyUnits()+" &cSell "+(long)row.getValue().sellUnits()));
                    if(rows.isEmpty()) sender.sendMessage(c("&7Belum ada data transaksi."));
                } catch (Exception ex) { sender.sendMessage(c("&cGagal membaca data market.")); }
            }
            default -> sender.sendMessage(c("&cGunakan: /aee [info|pause|resume|reload|run|top]"));
        }
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if(args.length==1) return List.of("info","pause","resume","reload","run","top").stream().filter(s->s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        return Collections.emptyList();
    }
}

package id.luxurygames.aed.persistence;

import id.luxurygames.aed.AIDynamicEconomy;

import java.io.File;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

/** Small transactional SQLite repository. All SQL access is serialized by synchronized methods. */
public final class MarketRepository implements AutoCloseable {
    private final Connection connection;
    public MarketRepository(AIDynamicEconomy plugin) throws SQLException {
        File file = new File(plugin.getDataFolder(), plugin.getConfig().getString("storage.sqlite-file", "market.db"));
        File parent = file.getParentFile(); if (parent != null) parent.mkdirs();
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL"); s.execute("PRAGMA synchronous=NORMAL");
            s.execute("CREATE TABLE IF NOT EXISTS market_signal (material TEXT PRIMARY KEY, buy_units REAL NOT NULL DEFAULT 0, sell_units REAL NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS price_baseline (price_key TEXT PRIMARY KEY, base_price REAL NOT NULL)");
        }
    }
    public synchronized void record(String material, double buy, double sell) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("INSERT INTO market_signal(material,buy_units,sell_units,updated_at) VALUES(?,?,?,?) ON CONFLICT(material) DO UPDATE SET buy_units=buy_units+excluded.buy_units,sell_units=sell_units+excluded.sell_units,updated_at=excluded.updated_at")) {
            p.setString(1, material); p.setDouble(2, buy); p.setDouble(3, sell); p.setLong(4, System.currentTimeMillis()); p.executeUpdate();
        }
    }
    public synchronized Map<String, Signal> signals(long decayWindowHours) throws SQLException {
        Map<String, Signal> map = new HashMap<>();
        long now = System.currentTimeMillis();
        long windowMillis = Math.max(1L, decayWindowHours) * 3_600_000L;
        try (Statement s = connection.createStatement(); ResultSet r = s.executeQuery("SELECT material,buy_units,sell_units,updated_at FROM market_signal")) {
            while (r.next()) {
                double decay = Math.exp(-Math.max(0L, now - r.getLong(4)) / (double) windowMillis);
                map.put(r.getString(1), new Signal(r.getDouble(2) * decay, r.getDouble(3) * decay));
            }
        } return map;
    }
    public synchronized double baseline(String key, double observed) throws SQLException {
        try (PreparedStatement q = connection.prepareStatement("SELECT base_price FROM price_baseline WHERE price_key=?")) {
            q.setString(1,key); try (ResultSet r=q.executeQuery()) { if(r.next()) return r.getDouble(1); }
        }
        try (PreparedStatement p=connection.prepareStatement("INSERT OR IGNORE INTO price_baseline(price_key,base_price) VALUES(?,?)")) { p.setString(1,key); p.setDouble(2,observed); p.executeUpdate(); }
        return observed;
    }
    public synchronized void flush() throws SQLException { try (Statement s=connection.createStatement()) { s.execute("PRAGMA wal_checkpoint(PASSIVE)"); } }
    @Override public synchronized void close() throws SQLException { connection.close(); }
    public record Signal(double buyUnits, double sellUnits) { }
}

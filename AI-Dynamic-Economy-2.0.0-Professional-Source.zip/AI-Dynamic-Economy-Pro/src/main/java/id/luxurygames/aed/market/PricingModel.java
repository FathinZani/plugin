package id.luxurygames.aed.market;

import id.luxurygames.aed.persistence.MarketRepository;

/** Deterministic bounded pricing model; independent buy/sell curves, no compounding. */
public final class PricingModel {
    private PricingModel() { }
    public static double multiplier(MarketRepository.Signal signal, boolean buySide, double sensitivityPercent,
                                    double smoothing, double maxChangePercent) {
        double activity = buySide ? signal.buyUnits() : signal.sellUnits();
        double opposing = buySide ? signal.sellUnits() : signal.buyUnits();
        // Logarithmic pressure limits the impact of extreme transaction volume.
        double pressure = Math.log1p(activity) - Math.log1p(opposing);
        double raw = Math.tanh(pressure / 5.0) * (sensitivityPercent / 100.0);
        // Buy price rises with demand; sell price falls as supply is sold into the shop.
        if (!buySide) raw = -raw;
        double smoothed = raw * Math.max(0.0, Math.min(1.0, smoothing));
        double cap = Math.max(0.0, maxChangePercent) / 100.0;
        return 1.0 + Math.max(-cap, Math.min(cap, smoothed));
    }
}

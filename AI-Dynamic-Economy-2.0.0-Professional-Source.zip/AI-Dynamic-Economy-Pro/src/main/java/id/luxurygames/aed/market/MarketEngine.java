package id.luxurygames.aed.market;

import id.luxurygames.aed.AIDynamicEconomy;
import id.luxurygames.aed.persistence.MarketRepository;
import me.gypopo.economyshopgui.api.events.PostTransactionEvent;
import me.gypopo.economyshopgui.util.Transaction;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class MarketEngine implements Listener {
    private final AIDynamicEconomy plugin;
    private final MarketRepository repository;
    private final Map<String, MarketRepository.Signal> pending = new ConcurrentHashMap<>();
    public MarketEngine(AIDynamicEconomy plugin, MarketRepository repository) { this.plugin=plugin; this.repository=repository; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPostTransaction(PostTransactionEvent event) {
        if (!plugin.isEngineEnabled() || !plugin.getConfig().getBoolean("features.transaction-tracking", true)) return;
        Transaction.Result result = event.getTransactionResult();
        if (result != Transaction.Result.SUCCESS && result != Transaction.Result.SUCCESS_COMMANDS_EXECUTED) return;
        Transaction.Mode mode = Transaction.Mode.getFromType(event.getTransactionType());
        if (event.getItems() != null && !event.getItems().isEmpty()) {
            event.getItems().forEach((shopItem, amount) -> { if (shopItem != null && shopItem.getItemToGive() != null) record(shopItem.getItemToGive().getType(), mode, amount); });
        } else if (event.getShopItem() != null && event.getShopItem().getItemToGive() != null) {
            record(event.getShopItem().getItemToGive().getType(), mode, event.getAmount());
        }
    }
    private void record(Material material, Transaction.Mode mode, int amount) {
        if (material == null || material.isAir() || amount <= 0) return;
        String key = material.name();
        MarketRepository.Signal old = pending.getOrDefault(key, new MarketRepository.Signal(0,0));
        pending.put(key, mode == Transaction.Mode.BUY
                ? new MarketRepository.Signal(old.buyUnits()+amount, old.sellUnits())
                : new MarketRepository.Signal(old.buyUnits(), old.sellUnits()+amount));
        // Persist each completed transaction immediately so a restart cannot erase market activity.
        try { repository.record(key, mode == Transaction.Mode.BUY ? amount : 0, mode == Transaction.Mode.SELL ? amount : 0); }
        catch (SQLException e) { plugin.getLogger().warning("Could not persist transaction signal: " + e.getMessage()); }
    }
    public Map<String, MarketRepository.Signal> snapshotSignals() {
        try { return repository.signals(plugin.getConfig().getLong("market.activity-window-hours", 168)); }
        catch (SQLException e) { plugin.getLogger().warning("Could not read market signals: " + e.getMessage()); return new HashMap<>(); }
    }
}

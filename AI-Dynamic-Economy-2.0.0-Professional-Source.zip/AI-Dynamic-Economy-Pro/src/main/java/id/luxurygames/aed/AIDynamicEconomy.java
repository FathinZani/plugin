package id.luxurygames.aed;

import id.luxurygames.aed.command.AeeCommand;
import id.luxurygames.aed.market.MarketEngine;
import id.luxurygames.aed.persistence.MarketRepository;
import id.luxurygames.aed.shop.ShopPriceService;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.sql.SQLException;

public final class AIDynamicEconomy extends JavaPlugin {
    private MarketRepository repository;
    private MarketEngine marketEngine;
    private ShopPriceService shopPriceService;
    private boolean paused;

    @Override public void onEnable() {
        saveDefaultConfig();
        try {
            repository = new MarketRepository(this);
            shopPriceService = new ShopPriceService(this, repository);
            marketEngine = new MarketEngine(this, repository);
        } catch (SQLException | IOException ex) {
            getLogger().severe("Failed to initialize storage/shop service: " + ex.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        if (Bukkit.getPluginManager().getPlugin("EconomyShopGUI") != null
                && getConfig().getBoolean("integration.economyshopgui.enabled", true)) {
            Bukkit.getPluginManager().registerEvents(marketEngine, this);
            getLogger().info("EconomyShopGUI Free detected; transaction listener registered.");
        } else {
            getLogger().warning("EconomyShopGUI Free was not detected. Market transaction tracking is idle.");
        }

        AeeCommand command = new AeeCommand(this);
        getCommand("aee").setExecutor(command);
        getCommand("aee").setTabCompleter(command);

        long delay = Math.max(1, getConfig().getLong("core.update-delay-ticks", 80));
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (isEngineEnabled() && getConfig().getBoolean("core.update-on-startup", true)) runMarketUpdate();
        }, delay);
        long flush = Math.max(10, getConfig().getLong("storage.flush-interval-seconds", 30));
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            try { repository.flush(); } catch (SQLException e) { getLogger().warning("Storage flush failed: " + e.getMessage()); }
        }, flush * 20L, flush * 20L);
        getLogger().info("AI Dynamic Economy v" + getDescription().getVersion() + " enabled.");
    }

    public void runMarketUpdate() {
        if (!isEngineEnabled() || paused) return;
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try {
                var result = shopPriceService.applyMarketPrices(marketEngine.snapshotSignals());
                Bukkit.getScheduler().runTask(this, () -> {
                    if (result.updatedFiles() > 0 && getConfig().getBoolean("integration.economyshopgui.reload-after-price-update", true)) {
                        String command = getConfig().getString("integration.economyshopgui.reload-command", "sreload");
                        if (command != null && !command.isBlank()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                    }
                    getLogger().info("Market update completed: " + result.updatedItems() + " item(s), " + result.updatedFiles() + " file(s).");
                });
            } catch (Exception e) { getLogger().severe("Market update failed safely: " + e.getMessage()); }
        });
    }

    public void reloadPluginConfig() { reloadConfig(); }
    public boolean isEngineEnabled() { return getConfig().getBoolean("core.enabled", true); }
    public boolean isPaused() { return paused; }
    public void setPaused(boolean value) { paused = value; }
    public MarketRepository repository() { return repository; }
    public MarketEngine marketEngine() { return marketEngine; }

    @Override public void onDisable() {
        if (repository != null) try { repository.flush(); repository.close(); } catch (SQLException e) { getLogger().warning("Could not close database cleanly: " + e.getMessage()); }
    }
}

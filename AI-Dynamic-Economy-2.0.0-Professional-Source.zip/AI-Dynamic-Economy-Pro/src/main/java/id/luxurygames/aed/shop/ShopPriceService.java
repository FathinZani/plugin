package id.luxurygames.aed.shop;

import id.luxurygames.aed.AIDynamicEconomy;
import id.luxurygames.aed.market.PricingModel;
import id.luxurygames.aed.persistence.MarketRepository;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Scans ESGUI shop YAML recursively; writes only scalar buy/sell fields after a backup. */
public final class ShopPriceService {
    private final AIDynamicEconomy plugin; private final MarketRepository repository;
    public ShopPriceService(AIDynamicEconomy plugin, MarketRepository repository) { this.plugin=plugin; this.repository=repository; }

    public UpdateResult applyMarketPrices(Map<String, MarketRepository.Signal> signals) throws Exception {
        File root = new File(plugin.getConfig().getString("integration.economyshopgui.shop-directory", "plugins/EconomyShopGUI/shops"));
        if (!root.exists() || !root.isDirectory()) throw new IOException("EconomyShopGUI shops directory not found: " + root.getAbsolutePath());
        List<File> files; try (var walk=Files.walk(root.toPath())) { files=walk.filter(p -> Files.isRegularFile(p) && (p.toString().endsWith(".yml") || p.toString().endsWith(".yaml"))).map(Path::toFile).toList(); }
        int changedFiles=0, changedItems=0;
        for (File file : files) {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            int changed = updateSection(yaml, "", file, signals);
            if (changed > 0) {
                if (plugin.getConfig().getBoolean("features.auto-backup", true)) backup(file);
                yaml.save(file); changedFiles++; changedItems += changed;
            }
        }
        return new UpdateResult(changedFiles, changedItems);
    }

    private int updateSection(ConfigurationSection section, String path, File file, Map<String, MarketRepository.Signal> signals) throws Exception {
        int count=0;
        for (String key : new ArrayList<>(section.getKeys(false))) {
            String childPath = path.isEmpty() ? key : path + "." + key;
            ConfigurationSection child = section.getConfigurationSection(key);
            if (child != null) {
                String materialName = child.getString("material", child.getString("type", ""));
                if (!materialName.isBlank()) count += updateItem(child, childPath, file, materialName, signals);
                else count += updateSection(child, childPath, file, signals);
            }
        }
        return count;
    }

    private int updateItem(ConfigurationSection item, String itemPath, File file, String materialName, Map<String, MarketRepository.Signal> signals) throws Exception {
        String normalized = materialName.toUpperCase(Locale.ROOT).replace("MINECRAFT:", "");
        MarketRepository.Signal signal = signals.getOrDefault(normalized, new MarketRepository.Signal(0,0));
        boolean changed=false;
        if (plugin.getConfig().getBoolean("features.dynamic-buy-prices", true) && (item.isDouble("buy") || item.isInt("buy")))
            changed |= updatePrice(item, "buy", file, itemPath, normalized, signal, true);
        if (plugin.getConfig().getBoolean("features.dynamic-sell-prices", true) && (item.isDouble("sell") || item.isInt("sell")))
            changed |= updatePrice(item, "sell", file, itemPath, normalized, signal, false);
        return changed ? 1 : 0;
    }

    private boolean updatePrice(ConfigurationSection item, String field, File file, String itemPath, String material,
                                MarketRepository.Signal signal, boolean buySide) throws Exception {
        double current = item.getDouble(field);
        if (plugin.getConfig().getBoolean("market.preserve-non-positive-prices", true) && current <= 0) return false;
        String key = file.getCanonicalPath() + "#" + itemPath + "#" + field;
        double base = repository.baseline(key, current);
        if (base <= 0) return false;
        double sensitivity = plugin.getConfig().getDouble("market.sensitivity-percent", 4.0);
        double smoothing = plugin.getConfig().getDouble("market.smoothing", 0.35);
        double cap = plugin.getConfig().getDouble("market.max-change-percent", 20.0);
        double multiplier = PricingModel.multiplier(signal, buySide, sensitivity, smoothing, cap);
        if (plugin.getConfig().getBoolean("features.random-market-events", false)) multiplier *= randomEventMultiplier();
        double updated = Math.max(base * (1-cap/100.0), Math.min(base * (1+cap/100.0), base * multiplier));
        if (Math.abs(updated-current) < 0.000001) return false;
        item.set(field, Math.round(updated * 10000.0) / 10000.0);
        return true;
    }
    private double randomEventMultiplier() {
        double chance=plugin.getConfig().getDouble("market.random-event-chance-percent",8.0);
        if (Math.random()*100.0 > chance) return 1.0;
        double max=plugin.getConfig().getDouble("market.random-event-max-percent",1.5)/100.0;
        return 1.0 + ((Math.random()*2.0-1.0)*max);
    }
    private void backup(File file) throws IOException {
        File dir=new File(plugin.getDataFolder(),plugin.getConfig().getString("backup.directory","backups"));
        if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Could not create backup directory");
        String stamp=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"));
        Files.copy(file.toPath(),new File(dir,file.getName()+"."+stamp+".bak").toPath());
    }
    public record UpdateResult(int updatedFiles,int updatedItems) { }
}

package id.luxurygames.aed.market;

import id.luxurygames.aed.persistence.MarketRepository;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PricingModelTest {
    @Test void neutralActivityKeepsBasePrice() {
        assertEquals(1.0, PricingModel.multiplier(new MarketRepository.Signal(0,0), true, 4, .35, 20), 1e-9);
    }
    @Test void multiplierNeverExceedsConfiguredCap() {
        double buy = PricingModel.multiplier(new MarketRepository.Signal(1_000_000,0), true, 50,.9,20);
        double sell = PricingModel.multiplier(new MarketRepository.Signal(0,1_000_000), false, 50,.9,20);
        assertTrue(buy <= 1.2 && buy >= .8);
        assertTrue(sell <= 1.2 && sell >= .8);
    }
    @Test void buyAndSellSignalsAreIndependent() {
        double buyPressure = PricingModel.multiplier(new MarketRepository.Signal(100,0), true, 10,.5,20);
        double sellPressure = PricingModel.multiplier(new MarketRepository.Signal(0,100), false, 10,.5,20);
        assertTrue(buyPressure > 1.0);
        assertTrue(sellPressure < 1.0);
    }
}

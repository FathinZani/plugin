@echo off
where mvn >nul 2>nul
if errorlevel 1 (
  echo Maven is not installed or not in PATH.
  exit /b 1
)
mvn -B clean verify
if errorlevel 1 exit /b 1
echo Build complete. Check target\AI-Dynamic-Economy-2.0.0.jar

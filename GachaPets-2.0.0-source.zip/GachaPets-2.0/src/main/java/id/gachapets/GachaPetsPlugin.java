package id.gachapets;

import com.petsplugin.PetsPlugin;
import com.petsplugin.model.PetInstance;
import com.petsplugin.model.PetType;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.*;

public final class GachaPetsPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private static final String[] TIERS = {"common","uncommon","rare","epic","legendary"};
    private static final int[] MENU_SLOTS = {10,11,12,13,14};
    private static final Material[] EGGS = {Material.EGG,Material.BEE_SPAWN_EGG,Material.TURTLE_EGG,Material.FOX_SPAWN_EGG,Material.DRAGON_EGG};
    private final Random random = new Random();
    private final Set<UUID> rolling = new HashSet<>();
    private Economy economy;
    private PetsPlugin pets;

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!(Bukkit.getPluginManager().getPlugin("BabyPets") instanceof PetsPlugin bp)) { getLogger().severe("BabyPets tidak ditemukan."); Bukkit.getPluginManager().disablePlugin(this); return; }
        pets = bp;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) { getLogger().severe("Vault economy provider tidak ditemukan."); Bukkit.getPluginManager().disablePlugin(this); return; }
        economy = rsp.getProvider();
        Objects.requireNonNull(getCommand("gachapets")).setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this,this);
        getLogger().info("GachaPets 2.0.0 aktif.");
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Command ini hanya untuk pemain."); return true; }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) { if (!p.hasPermission("gachapets.admin")) { p.sendMessage(c("&cTidak punya izin.")); return true; } reloadConfig(); p.sendMessage(c("&aConfig GachaPets dimuat ulang.")); return true; }
        if (!p.hasPermission("gachapets.use")) { p.sendMessage(c("&cKamu tidak punya izin.")); return true; }
        openMenu(p); return true;
    }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(new GachaHolder(),27,c("&8&lGACHAPETS"));
        fill(inv, Material.BLACK_STAINED_GLASS_PANE);
        for (int i=0;i<TIERS.length;i++) {
            String tier=TIERS[i]; double price=getConfig().getDouble("prices."+tier,1000);
            inv.setItem(MENU_SLOTS[i], make(EGGS[i], "&f&l"+tier.toUpperCase()+" EGG", "&7Harga: &a$"+String.format(Locale.US,"%,.0f",price), "", "&eKlik untuk membuka!"));
        }
        inv.setItem(22,make(Material.BOOK,"&b&lPELUANG HADIAH","&7Item: &e45%", "&7Zonk: &c35%", "&7Pet: &a20%", "", "&8Peluang rarity berlaku jika mendapat pet."));
        inv.setItem(16,make(Material.CHEST,"&b&lKOLEKSI PET","&7Buka koleksi Baby Pets.","&eKlik untuk /pets"));
        p.openInventory(inv);
    }

    @EventHandler public void click(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GachaHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory()!=e.getView().getTopInventory()) return;
        int slot=e.getRawSlot();
        for(int i=0;i<MENU_SLOTS.length;i++) if(slot==MENU_SLOTS[i]) { startRoll(p,TIERS[i]); return; }
        if(slot==16) { p.closeInventory(); p.performCommand("pets"); }
    }
    @EventHandler public void drag(InventoryDragEvent e) { if(e.getView().getTopInventory().getHolder() instanceof GachaHolder)e.setCancelled(true); }
    @EventHandler public void quit(PlayerQuitEvent e) { /* The paid roll completes; offline reward failures are refunded. */ }

    private void startRoll(Player p,String tier) {
        UUID id=p.getUniqueId(); if(!rolling.add(id)){p.sendMessage(c("&cRoulette masih berjalan."));return;}
        double price=getConfig().getDouble("prices."+tier,-1);
        if(price<0 || !economy.has(p,price)){rolling.remove(id);p.sendMessage(c("&cSaldo tidak cukup."));return;}
        Reward reward=chooseReward(tier);
        if(reward.kind.equals("pet") && (reward.petId==null || !pets.getPetTypes().containsKey(reward.petId))) { rolling.remove(id);p.sendMessage(c("&cPet reward belum terdaftar di BabyPets: "+reward.petId));return; }
        if(!economy.withdrawPlayer(p,price).transactionSuccess()){rolling.remove(id);p.sendMessage(c("&cPembayaran gagal."));return;}
        Inventory inv=Bukkit.createInventory(new GachaHolder(),27,c("&8&lEGG ROULETTE")); fill(inv,Material.BLACK_STAINED_GLASS_PANE);
        inv.setItem(4,make(EGGS[Arrays.asList(TIERS).indexOf(tier)],"&e&l"+tier.toUpperCase()+" EGG","&7Menentukan hadiah..."));
        p.openInventory(inv);
        List<ItemStack> strip=new ArrayList<>();
        for(int i=0;i<7;i++) strip.add(randomPreview(tier));
        strip.set(3,reward.icon());
        final int[] step={0}; final int total=Math.max(12,getConfig().getInt("roulette.steps",24));
        new BukkitRunnable(){
            void render(){ Player online=Bukkit.getPlayer(id); if(online==null || !online.isOnline()) { cancel(); economy.depositPlayer(Bukkit.getOfflinePlayer(id),price); rolling.remove(id); return; }
                Inventory top=online.getOpenInventory().getTopInventory(); if(!(top.getHolder() instanceof GachaHolder)){ top=Bukkit.createInventory(new GachaHolder(),27,c("&8&lEGG ROULETTE")); online.openInventory(top); }
                for(int i=0;i<7;i++) top.setItem(10+i, strip.get(i));
                top.setItem(4,make(Material.PURPLE_STAINED_GLASS_PANE,"&e&lHADIAH TERPILIH","&7Berhenti di tengah"));
            }
            @Override public void run(){
                if(step[0]>=total){ cancel(); finish(id,p.getName(),tier,reward,price); return; }
                Collections.rotate(strip,1); if(step[0]==total-1) strip.set(3,reward.icon());
                render(); if(Bukkit.getPlayer(id)!=null) Bukkit.getPlayer(id).playSound(Bukkit.getPlayer(id).getLocation(),Sound.UI_BUTTON_CLICK,.65f,1.0f+step[0]*.025f);
                int delay=(int)(getConfig().getInt("roulette.starting-delay",2)+((double)step[0]/total)*(getConfig().getInt("roulette.ending-delay",12)-getConfig().getInt("roulette.starting-delay",2)));
                step[0]++; Bukkit.getScheduler().runTaskLater(GachaPetsPlugin.this,this,Math.max(1,delay));
            }
        }.runTaskLater(this,1L);
    }

    private Reward chooseReward(String tier) {
        int item=getConfig().getInt("outcomes.item",45), zonk=getConfig().getInt("outcomes.zonk",35);
        int roll=random.nextInt(100); if(roll<item) return itemReward(tier); if(roll<item+zonk) return Reward.zonk();
        String rarity=rollRarity(tier); List<String> pool=getConfig().getStringList("pets."+rarity);
        if(pool.isEmpty()) return Reward.zonk(); String pet=pool.get(random.nextInt(pool.size())).toLowerCase(Locale.ROOT);
        PetType type=pets.getPetTypes().get(pet); String display=type==null?pet:type.getDisplayName();
        return Reward.pet(pet,make(type==null?Material.EGG:type.getIcon(),"&a&lPET: "+display,"&7Rarity: "+rarity));
    }
    private Reward itemReward(String tier) {
        List<String> entries=getConfig().getStringList("item-rewards."+tier); if(entries.isEmpty()) return Reward.zonk();
        String[] bits=entries.get(random.nextInt(entries.size())).split(":");
        try { Material m=Material.valueOf(bits[0].toUpperCase(Locale.ROOT)); int amount=bits.length>1?Integer.parseInt(bits[1]):1; return Reward.item(new ItemStack(m,Math.max(1,Math.min(amount,m.getMaxStackSize())))); }
        catch(Exception ex){getLogger().warning("Item reward config invalid: "+entries);return Reward.zonk();}
    }
    private ItemStack randomPreview(String tier) { List<String> pool=getConfig().getStringList("pets."+tier); if(pool.isEmpty())return make(Material.GRAY_STAINED_GLASS_PANE,"&7???"); String id=pool.get(random.nextInt(pool.size())); PetType t=pets.getPetTypes().get(id.toLowerCase(Locale.ROOT)); return make(t==null?Material.EGG:t.getIcon(),"&f"+(t==null?id:t.getDisplayName())); }
    private String rollRarity(String tier) { ConfigurationSection s=getConfig().getConfigurationSection("chances."+tier); if(s==null)return tier; int n=random.nextInt(10000)+1,sum=0; for(String r:TIERS){sum+=s.getInt(r,0);if(n<=sum)return r;}return tier; }

    private void finish(UUID id,String playerName,String tier,Reward reward,double price) {
        Player p=Bukkit.getPlayer(id);
        try {
            if(p==null || !p.isOnline()) throw new IllegalStateException("Player offline before reward delivery");
            if(reward.kind.equals("pet")) {
                PetType type=pets.getPetTypes().get(reward.petId); if(type==null)throw new IllegalStateException("Pet ID tidak ditemukan: "+reward.petId);
                PetInstance instance=PetInstance.createNew(id,type.getId()); pets.getPetManager().ensurePersistentAppearance(instance,type);
                if(pets.getDatabaseManager().insertPet(instance)<=0)throw new IllegalStateException("Database BabyPets gagal menyimpan pet");
                pets.getPetManager().refreshCache(id);
                p.sendMessage(c("&aBerhasil mendapatkan pet &f"+type.getDisplayName()+" &a!"));
                if("legendary".equals(rollRarityForReward(tier,reward.petId))) Bukkit.broadcastMessage(c("&6✦ "+playerName+" mendapatkan pet langka dari GachaPets!"));
            } else if(reward.kind.equals("item")) {
                Map<Integer,ItemStack> left=p.getInventory().addItem(reward.item.clone()); left.values().forEach(it->p.getWorld().dropItemNaturally(p.getLocation(),it));
                p.sendMessage(c("&aHadiah item: &f"+reward.item.getAmount()+"x "+pretty(reward.item.getType())));
            } else { p.sendMessage(c("&cZONK! &7Kali ini belum beruntung. Coba lagi nanti.")); }
            p.playSound(p.getLocation(),reward.kind.equals("zonk")?Sound.ENTITY_VILLAGER_NO:Sound.UI_TOAST_CHALLENGE_COMPLETE,1f,1f);
            p.closeInventory();
        } catch(Exception ex) { getLogger().warning("Reward gagal untuk "+playerName+": "+ex.getMessage()); economy.depositPlayer(Bukkit.getOfflinePlayer(id),price); if(p!=null)p.sendMessage(c("&cReward gagal diproses. Uang dikembalikan.")); }
        finally { rolling.remove(id); }
    }
    // The pet's configured rarity is determined from the actual configured tier pool.
    private String rollRarityForReward(String requested,String petId){ for(String r:TIERS)if(getConfig().getStringList("pets."+r).contains(petId))return r;return requested; }
    private String pretty(Material m){return m.name().toLowerCase(Locale.ROOT).replace('_',' ');}
    private void fill(Inventory inv,Material m){ItemStack pane=make(m," ");for(int i=0;i<inv.getSize();i++)inv.setItem(i,pane);}
    private ItemStack make(Material m,String name,String... lore){ItemStack it=new ItemStack(m);ItemMeta meta=it.getItemMeta();meta.setDisplayName(c(name));if(lore.length>0)meta.setLore(Arrays.stream(lore).map(this::c).toList());it.setItemMeta(meta);return it;}
    private String c(String s){return ChatColor.translateAlternateColorCodes('&',s);}
    private record Reward(String kind,String petId,ItemStack item,ItemStack display){static Reward pet(String id,ItemStack icon){return new Reward("pet",id,null,icon);}static Reward item(ItemStack it){return new Reward("item",null,it,it.clone());}static Reward zonk(){return new Reward("zonk",null,null,new ItemStack(Material.BARRIER));}ItemStack icon(){if(display!=null)return display.clone();if(item!=null)return item.clone();ItemStack z=new ItemStack(Material.BARRIER);ItemMeta m=z.getItemMeta();m.setDisplayName(ChatColor.RED+"ZONK");z.setItemMeta(m);return z;}}
    private static final class GachaHolder implements InventoryHolder {public Inventory getInventory(){return null;}}
}

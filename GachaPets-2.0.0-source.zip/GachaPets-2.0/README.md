# GachaPets 2.0.0

Paper 1.21.3 / Java 21 / Maven. Requires Vault + an economy provider and BabyPets 1.3.1.

## Build
`mvn clean package`

The built plugin is `target/GachaPets-2.0.0.jar`.

## Install
1. Keep BabyPets and Vault installed.
2. Put `GachaPets-2.0.0.jar` in `plugins/`.
3. Start the server once, then edit `plugins/GachaPets/config.yml` if needed.
4. Use `/gachapets`; admin reload: `/gachapets reload`.

Reward category odds default to 45% item, 35% zonk, 20% pet. Pet rarity weights are evaluated only when the pet category wins. GUI uses ordinary Bukkit inventories for Geyser-compatible interaction.

The BabyPets 1.3.1 JAR is included in `libs/` only as a compile-time API dependency; it is not shaded into the output. Do not remove BabyPets from the server.
